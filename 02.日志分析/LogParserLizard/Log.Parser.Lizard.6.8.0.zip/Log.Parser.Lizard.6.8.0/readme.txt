Install, run program in trial mode, close.
Copy "LogParserLizard.config" to "C:\Users\USERNAME\AppData\Local\LizardLabs\"